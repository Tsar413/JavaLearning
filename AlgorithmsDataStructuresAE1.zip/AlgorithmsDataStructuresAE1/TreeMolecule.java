package com.company.javaRelearn.AlgorithmsDataStructuresAE1;

//add name and id as comment

//add import statement


public class TreeMolecule implements Molecule {

    private Atom first;

    //add constructor, implemented methods and any helper methods you require

    public TreeMolecule(Atom atom) {
        this.first = atom;
    }

    @Override
    public boolean addBond(Atom a1, Atom a2, int strength) {
        Bond bond1 = new Bond(a2,strength);
        int index1 = 0;
        int index2 = 0;
        int availableLocation1 = 0;
        int availableLocation2 = 0;
        for (int i = 0; i < a1.getBonds().size(); i++) {
            if (a1.getBonds().get(i).getChild().getElement().equals("H")) {
                availableLocation1++;
            }
        }
        for (int i = 0; i < a2.getBonds().size(); i++) {
            if (a2.getBonds().get(i).getChild().getElement().equals("H")) {
                availableLocation2++;
            }
        }
        if ((strength > availableLocation1) || (strength > availableLocation2)) {
            return false;
        }

        int temp1 = a1.getBonds().size();
        int judge1 = 0;
        for (int i = 0; i < temp1; i++) {
            if (a1.getBonds().get(judge1).getChild().getElement().equals("H") && (index1 < strength)) {
                a1.getBonds().remove(judge1);
                index1++;
            } else if (!a1.getBonds().get(judge1).getChild().getElement().equals("H")) {
                judge1++;
            }
        }

        int temp2 = a2.getBonds().size();
        int judge2 = 0;
        for (int i = 0; i < temp2; i++) {
            if (a2.getBonds().get(judge2).getChild().getElement().equals("H") && (index2 < strength)) {
                a2.getBonds().remove(judge2);
                index2++;
            } else if (!a2.getBonds().get(judge2).getChild().getElement().equals("H")) {
                judge2++;
            }
        }
        a1.getBonds().add(bond1);
        return true;
    }

    @Override
    public boolean contains(Atom a) {
        return containHelper(first, a);
    }

    @Override
    public String smilesString() {
        String result = "";
        result = smileHelper(first, result);
        return result;
    }

    @Override
    public String structuralFormula() {
        String result = "";
        result = structuralHelper(first, result);
        return result;
    }

    public boolean containHelper(Atom data, Atom a) {
        boolean result = false;
        if (data.equals(a)) {
            result = true;
        }
        for (int i = 0; i < data.getBonds().size(); i++) {
            if (data.getBonds().get(i).getChild().equals(a)) {
                result = true;
            } else {
                result = containHelper(data.getBonds().get(i).getChild(), a);
            }
        }
        return result;
    }

    public String smileHelper(Atom data, String result) {
        if (!data.getElement().equals("H")) {
            result += data.getElement();
        }
        int temp = 0;
        for (int i = 0; i < data.getBonds().size(); i++) {
            if (!data.getBonds().get(i).getChild().getElement().equals("H")) {
                temp ++;
            }
        }
        for (int i = 0; i < data.getBonds().size(); i++) {
            if (!data.getBonds().get(i).getChild().getElement().equals("H")) {
                if (temp > 1) {
                    result += "(";
                }
                if (data.getBonds().get(i).getWeight() == 2) {
                    result += "=";
                } else if (data.getBonds().get(i).getWeight() == 3) {
                    result += "#";
                }
                result = smileHelper(data.getBonds().get(i).getChild(), result);
                if (temp > 1) {
                    result += ")";
                }
            }
        }
        return result;
    }

    public String structuralHelper(Atom data, String result) {
        if (!data.getElement().equals("H")) {
            result += data.getElement();
        }
        int calH;
        int temp = 0;
        for (int i = 0; i < data.getBonds().size(); i++) {
            if (!data.getBonds().get(i).getChild().getElement().equals("H")) {
                temp ++;
            }
        }
        calH = data.getBonds().size() - temp;
        if (calH > 0) {
            result += "H";
        }
        if (calH > 1) {
            result += calH;
        }
        for (int i = 0; i < data.getBonds().size(); i++) {
            if (!data.getBonds().get(i).getChild().getElement().equals("H")) {
                if (temp > 1) {
                    result += "(";
                }
                if (data.getBonds().get(i).getWeight() == 2) {
                    result += "=";
                } else if (data.getBonds().get(i).getWeight() == 3) {
                    result += "#";
                }
                result = structuralHelper(data.getBonds().get(i).getChild(), result);
                if (temp > 1) {
                    result += ")";
                }
            }
        }
        return result;
    }
}
