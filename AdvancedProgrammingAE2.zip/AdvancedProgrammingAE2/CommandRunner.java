package com.company.javaRelearn.AdvancedProgrammingAE2;

public interface CommandRunner {
    String runCommand(String command);
}
