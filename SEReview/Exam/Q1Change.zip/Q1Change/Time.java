package com.company.javaRelearn.SEReview.Exam.Q1Change;

public class Time {
    public int day;
    public int month;
    public int year;

    public Time() {
    }

    public Time(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    @Override
    public String toString() {
        return "Time{" +
                "day=" + day +
                ", month=" + month +
                ", year=" + year +
                '}';
    }
}
