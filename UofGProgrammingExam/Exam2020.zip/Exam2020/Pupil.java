package com.company.javaRelearn.UofGProgrammingExam.Exam2020;

public class Pupil implements Comparable {
    private String firstName;
    private String secondName;
    private Integer numberOfPoints;
    private String reasonForPoints;

    public Pupil() {}

    public Pupil(String firstName, String secondName, Integer numberOfPoints, String reasonForPoints) {
        this.firstName = firstName;
        this.secondName = secondName;
        this.numberOfPoints = numberOfPoints;
        this.reasonForPoints = reasonForPoints;
    }

    public Pupil(String firstName, String secondName, AwardedPoints awardedPoints) {
        this.firstName = firstName;
        this.secondName = secondName;
        this.numberOfPoints = awardedPoints.getNumberOfPoints();
        this.reasonForPoints = awardedPoints.getReasonForPoints();
    }

    public Pupil(String firstName, String secondName) {
        this.firstName = firstName;
        this.secondName = secondName;
        this.numberOfPoints = 0;
        this.reasonForPoints = "";
    }

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }
    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public Integer getNumberOfPoints() {
        return numberOfPoints;
    }
    public void setNumberOfPoints(Integer numberOfPoints) {
        this.numberOfPoints = numberOfPoints;
    }

    public String getReasonForPoints() {
        return reasonForPoints;
    }
    public void setReasonForPoints(String reasonForPoints) {
        this.reasonForPoints = reasonForPoints;
    }

    public boolean equals(Object o) {
        if (!(o instanceof Pupil)) {
            return false;
        } else {
            Pupil other = (Pupil) o;
            if ((this.firstName.equals(other.firstName))&&(this.secondName.equals(other.secondName))) {
                return true;
            } else {
                return false;
            }
        }
    }

    public static Pupil[] add(Pupil[] pupils, Pupil pupil, AwardedPoints awardedPoints) {
        int result = -1;
        for (int i = 0; i < pupils.length; i++) {
            if (pupils[i].equals(pupil)) {
                result = i;
            }
        }
        if (result != -1) {
            pupils[result].numberOfPoints = pupils[result].numberOfPoints + awardedPoints.getNumberOfPoints();
            pupils[result].reasonForPoints = pupils[result].reasonForPoints + awardedPoints.getReasonForPoints();
            return pupils;
        } else {
            Pupil[] newPupils = new Pupil[pupils.length + 1];
            Pupil newPupil = new Pupil(pupil.firstName, pupil.secondName, awardedPoints);
            for (int i = 0; i < pupils.length; i++) {
                newPupils[i] = pupils[i];
            }
            newPupils[newPupils.length - 1] = newPupil;
            return newPupils;
        }
    }

    @Override
    public int compareTo(Object o) {
        if (!(o instanceof Pupil)) {
            return 0;
        } else {
            Pupil other = (Pupil) o;
            if (this.numberOfPoints < other.numberOfPoints) {
                return 1;
            } else {
                return -1;
            }
        }
    }

    @Override
    public String toString() {
        return "Pupil{" +
                "firstName='" + firstName + '\'' +
                ", secondName='" + secondName + '\'' +
                ", numberOfPoints=" + numberOfPoints +
                ", reasonForPoints='" + reasonForPoints + '\'' +
                '}';
    }
}
