package com.company.javaRelearn.UofGProgrammingExam.Exam2020;

public class Test {
    public static void main(String[] args) throws Exception {
        ReadFiles readFiles = new ReadFiles();
        AwardedPoints awardedPoints = new AwardedPoints(1,"Help");
        Pupil pupil = new Pupil("A","B",awardedPoints);
        Pupil[] pupils = readFiles.getPupils();
        pupils = Pupil.add(pupils,pupil,awardedPoints);
        for (Pupil p : pupils) {
            System.out.println(p);
        }
    }
}
